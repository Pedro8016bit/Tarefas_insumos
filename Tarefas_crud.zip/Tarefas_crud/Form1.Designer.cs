﻿namespace Tarefas_crud
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            txt_login = new TextBox();
            txt_senha = new TextBox();
            label2 = new Label();
            btn_login = new Button();
            btn_chamar_cad = new LinkLabel();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(72, 74);
            label1.Name = "label1";
            label1.Size = new Size(40, 15);
            label1.TabIndex = 0;
            label1.Text = "Login:";
            // 
            // txt_login
            // 
            txt_login.Location = new Point(75, 92);
            txt_login.Name = "txt_login";
            txt_login.Size = new Size(152, 23);
            txt_login.TabIndex = 1;
            // 
            // txt_senha
            // 
            txt_senha.Location = new Point(75, 154);
            txt_senha.Name = "txt_senha";
            txt_senha.Size = new Size(152, 23);
            txt_senha.TabIndex = 3;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(75, 136);
            label2.Name = "label2";
            label2.Size = new Size(42, 15);
            label2.TabIndex = 2;
            label2.Text = "Senha:";
            // 
            // btn_login
            // 
            btn_login.Location = new Point(112, 198);
            btn_login.Name = "btn_login";
            btn_login.Size = new Size(75, 23);
            btn_login.TabIndex = 4;
            btn_login.Text = "Logar";
            btn_login.UseVisualStyleBackColor = true;
            btn_login.Click += btn_login_Click;
            // 
            // btn_chamar_cad
            // 
            btn_chamar_cad.AutoSize = true;
            btn_chamar_cad.Location = new Point(115, 224);
            btn_chamar_cad.Name = "btn_chamar_cad";
            btn_chamar_cad.Size = new Size(69, 15);
            btn_chamar_cad.TabIndex = 5;
            btn_chamar_cad.TabStop = true;
            btn_chamar_cad.Text = "Cadastre-se";
            btn_chamar_cad.LinkClicked += btn_chamar_cad_LinkClicked;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(303, 312);
            Controls.Add(btn_chamar_cad);
            Controls.Add(btn_login);
            Controls.Add(txt_senha);
            Controls.Add(label2);
            Controls.Add(txt_login);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox txt_login;
        private TextBox txt_senha;
        private Label label2;
        private Button btn_login;
        private LinkLabel btn_chamar_cad;
    }
}
