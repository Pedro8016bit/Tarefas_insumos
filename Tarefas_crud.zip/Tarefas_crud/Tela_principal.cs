﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tarefas_crud
{
    public partial class Tela_principal : Form
    {
        public Tela_principal()
        {
            InitializeComponent();
        }
        public void CarregarPainel()
        {
            try
            {
                using (MySqlConnection conexao = new BancoDb().Conectar())
                {
                    string query = "Select id_usuario from tarefa";
                    MySqlCommand cmd = new MySqlCommand(query, conexao);
                    MySqlDataAdapter adapter = new MySqlDataAdapter(cmd);
                    DataTable tabela = new DataTable();
                    adapter.Fill(tabela);
                    dgv.DataSource = tabela;
                    dgv.AllowUserToAddRows = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("erro ao carregar" + ex.Message);
            }
        }

        private void Tela_principal_Load(object sender, EventArgs e)
        {
            CarregarPainel();
        }

        private void btn_adcionar_Click(object sender, EventArgs e)
        {
            Tarefa tarefa = new Tarefa();

            tarefa.Titulo = txt_titulo.Text;
            tarefa.Descricao = txt_descricao.Text;
            tarefa.Entrega_dia = txt_data.Text;
            tarefa.Andamento = txt_pendencia.Text;

            if(!txt_titulo.Text.Equals("") && !txt_descricao.Text.Equals("") && !txt_data.Text.Equals("") && !txt_pendencia.Text.Equals(""))
            {
                bool funciona = tarefa.Cadastrar_item();
                if (funciona)
                {
                    MessageBox.Show("sucesso");
                    CarregarPainel();
                }
                else
                {
                    MessageBox.Show("erro");
                }
            }
            else
            {
                MessageBox.Show("erro");
            }
        }
    }
}
