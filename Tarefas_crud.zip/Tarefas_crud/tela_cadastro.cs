﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tarefas_crud
{
    public partial class tela_cadastro : Form
    {
        public tela_cadastro()
        {
            InitializeComponent();
        }

        private void btn_cad_Click(object sender, EventArgs e)
        {
            Form1 tela = new Form1();
            Usuario usuario = new Usuario();
            usuario.Email = txt_email.Text;
            usuario.Senha = txt_senha.Text;
            usuario.Login = txt_login.Text;
            usuario.Nome = txt_nome.Text;

            bool funciona = usuario.CadastarUser();
            if (!txt_nome.Text.Equals("") && !txt_login.Text.Equals("") && !txt_email.Text.Equals("") && !txt_senha.Text.Equals(""))
            {
                if (funciona)
                {
                    MessageBox.Show("cadastro feito com sucesso!!");
                    tela.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("erro ao cadastar");
                }
            }
        }
    }
}
