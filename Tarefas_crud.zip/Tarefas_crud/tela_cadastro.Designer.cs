﻿namespace Tarefas_crud
{
    partial class tela_cadastro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            txt_nome = new TextBox();
            txt_login = new TextBox();
            label3 = new Label();
            txt_email = new TextBox();
            label4 = new Label();
            txt_senha = new TextBox();
            label5 = new Label();
            btn_cad = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(93, 38);
            label1.Name = "label1";
            label1.Size = new Size(75, 20);
            label1.TabIndex = 0;
            label1.Text = "Cadastro ";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(41, 81);
            label2.Name = "label2";
            label2.Size = new Size(43, 15);
            label2.TabIndex = 1;
            label2.Text = "Nome:";
            // 
            // txt_nome
            // 
            txt_nome.Location = new Point(41, 99);
            txt_nome.Name = "txt_nome";
            txt_nome.Size = new Size(183, 23);
            txt_nome.TabIndex = 2;
            // 
            // txt_login
            // 
            txt_login.Location = new Point(41, 146);
            txt_login.Name = "txt_login";
            txt_login.Size = new Size(183, 23);
            txt_login.TabIndex = 4;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(42, 128);
            label3.Name = "label3";
            label3.Size = new Size(40, 15);
            label3.TabIndex = 3;
            label3.Text = "Login:";
            // 
            // txt_email
            // 
            txt_email.Location = new Point(41, 193);
            txt_email.Name = "txt_email";
            txt_email.Size = new Size(183, 23);
            txt_email.TabIndex = 6;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(41, 175);
            label4.Name = "label4";
            label4.Size = new Size(39, 15);
            label4.TabIndex = 5;
            label4.Text = "Email:";
            // 
            // txt_senha
            // 
            txt_senha.Location = new Point(41, 241);
            txt_senha.Name = "txt_senha";
            txt_senha.Size = new Size(183, 23);
            txt_senha.TabIndex = 8;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(41, 223);
            label5.Name = "label5";
            label5.Size = new Size(42, 15);
            label5.TabIndex = 7;
            label5.Text = "Senha:";
            // 
            // btn_cad
            // 
            btn_cad.Location = new Point(93, 270);
            btn_cad.Name = "btn_cad";
            btn_cad.Size = new Size(75, 23);
            btn_cad.TabIndex = 9;
            btn_cad.Text = "Cadastro";
            btn_cad.UseVisualStyleBackColor = true;
            btn_cad.Click += btn_cad_Click;
            // 
            // tela_cadastro
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(267, 320);
            Controls.Add(btn_cad);
            Controls.Add(txt_senha);
            Controls.Add(label5);
            Controls.Add(txt_email);
            Controls.Add(label4);
            Controls.Add(txt_login);
            Controls.Add(label3);
            Controls.Add(txt_nome);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "tela_cadastro";
            Text = "tela_cadastro";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox txt_nome;
        private TextBox txt_login;
        private Label label3;
        private TextBox txt_email;
        private Label label4;
        private TextBox txt_senha;
        private Label label5;
        private Button btn_cad;
    }
}