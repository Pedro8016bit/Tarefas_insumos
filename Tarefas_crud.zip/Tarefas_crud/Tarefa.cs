﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tarefas_crud
{
    class Tarefa
    {
        private int id_tarefa;
        private string titulo;
        private string descricao;
        private string andamento;
        private string entrega_dia;

        public int Id_tarefa
        {
            get { return id_tarefa; }
            set { id_tarefa = value; }
        }
        public string Titulo
        {
            get { return titulo; }
            set { titulo = value; }
        } 
        public string Descricao
        {
            get { return descricao; }
            set { descricao = value; }
        }
        public string Andamento
        {
            get { return andamento; }
            set { andamento = value; }
        }
        public string Entrega_dia
        {
            get { return entrega_dia; }
            set { entrega_dia = value; }
        }

        public bool Cadastrar_item()
        {
            try
            {
                using (MySqlConnection conexao = new BancoDb().Conectar())
                {
                    Usuario user = new Usuario();
                    string query = "INSERT INTO tarefa(titulo, descricao, andamento, entrega_dia, id_usuario) Values(@titulo, @descricao, @andamento, @entrega_dia, @id_usuario)";

                    MySqlCommand cmd = new MySqlCommand(query, conexao);
                    cmd.Parameters.AddWithValue("@titulo", Titulo);
                    cmd.Parameters.AddWithValue("@descricao", Descricao);
                    cmd.Parameters.AddWithValue("@andamento", Andamento);
                    cmd.Parameters.AddWithValue("@Entrega_dia", Entrega_dia);
                    cmd.Parameters.AddWithValue("@id_usuario", user.Id);

                    int res = Convert.ToInt32(cmd.ExecuteNonQuery());

                    if(res > 0)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }

                }
            }
            catch(Exception ex)
            {
                MessageBox.Show("erro no catch da tarefa" + ex.Message);
                return false;
            }
        }

        public void CarregarPainel()
        {
            try
            {
                using (MySqlConnection conexao = new BancoDb().Conectar())
                {
                    string query = "Select id_usuario from tarefa";
                    MySqlCommand cmd = new MySqlCommand(query, conexao);
                    MySqlDataAdapter adapter = new MySqlDataAdapter(cmd);
                    DataTable tabela = new DataTable();
                    adapter.Fill(tabela);
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show("erro ao carregar" + ex.Message);
            }
        }
    }
}
