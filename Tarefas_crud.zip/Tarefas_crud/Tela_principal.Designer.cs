﻿namespace Tarefas_crud
{
    partial class Tela_principal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dgv = new DataGridView();
            label1 = new Label();
            txt_id_tarefa = new Label();
            label2 = new Label();
            txt_titulo = new TextBox();
            txt_descricao = new TextBox();
            label3 = new Label();
            txt_data = new MaskedTextBox();
            label4 = new Label();
            label5 = new Label();
            txt_pendencia = new ComboBox();
            btn_adcionar = new Button();
            btn_update = new Button();
            btn_delete = new Button();
            ((System.ComponentModel.ISupportInitialize)dgv).BeginInit();
            SuspendLayout();
            // 
            // dgv
            // 
            dgv.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgv.Location = new Point(12, 12);
            dgv.Name = "dgv";
            dgv.Size = new Size(776, 246);
            dgv.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(37, 285);
            label1.Name = "label1";
            label1.Size = new Size(53, 15);
            label1.TabIndex = 1;
            label1.Text = "Id tarefa:";
            // 
            // txt_id_tarefa
            // 
            txt_id_tarefa.AutoSize = true;
            txt_id_tarefa.Location = new Point(37, 300);
            txt_id_tarefa.Name = "txt_id_tarefa";
            txt_id_tarefa.Size = new Size(0, 15);
            txt_id_tarefa.TabIndex = 2;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(184, 285);
            label2.Name = "label2";
            label2.Size = new Size(41, 15);
            label2.TabIndex = 3;
            label2.Text = "Titulo:";
            // 
            // txt_titulo
            // 
            txt_titulo.Location = new Point(184, 300);
            txt_titulo.Name = "txt_titulo";
            txt_titulo.Size = new Size(91, 23);
            txt_titulo.TabIndex = 4;
            // 
            // txt_descricao
            // 
            txt_descricao.Location = new Point(338, 300);
            txt_descricao.Name = "txt_descricao";
            txt_descricao.Size = new Size(450, 23);
            txt_descricao.TabIndex = 6;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(338, 285);
            label3.Name = "label3";
            label3.Size = new Size(61, 15);
            label3.TabIndex = 5;
            label3.Text = "Descrição:";
            // 
            // txt_data
            // 
            txt_data.Location = new Point(184, 363);
            txt_data.Mask = "00/00/0000";
            txt_data.Name = "txt_data";
            txt_data.Size = new Size(100, 23);
            txt_data.TabIndex = 7;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(184, 345);
            label4.Name = "label4";
            label4.Size = new Size(34, 15);
            label4.TabIndex = 8;
            label4.Text = "Data:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(37, 345);
            label5.Name = "label5";
            label5.Size = new Size(73, 15);
            label5.TabIndex = 9;
            label5.Text = "Andamento:";
            // 
            // txt_pendencia
            // 
            txt_pendencia.FormattingEnabled = true;
            txt_pendencia.Items.AddRange(new object[] { "Concluida", "Em andamento", "Pendente" });
            txt_pendencia.Location = new Point(37, 363);
            txt_pendencia.Name = "txt_pendencia";
            txt_pendencia.Size = new Size(114, 23);
            txt_pendencia.TabIndex = 10;
            // 
            // btn_adcionar
            // 
            btn_adcionar.Location = new Point(338, 362);
            btn_adcionar.Name = "btn_adcionar";
            btn_adcionar.Size = new Size(75, 23);
            btn_adcionar.TabIndex = 11;
            btn_adcionar.Text = "Add";
            btn_adcionar.UseVisualStyleBackColor = true;
            btn_adcionar.Click += btn_adcionar_Click;
            // 
            // btn_update
            // 
            btn_update.Location = new Point(468, 363);
            btn_update.Name = "btn_update";
            btn_update.Size = new Size(75, 23);
            btn_update.TabIndex = 12;
            btn_update.Text = "Editar";
            btn_update.UseVisualStyleBackColor = true;
            // 
            // btn_delete
            // 
            btn_delete.Location = new Point(599, 362);
            btn_delete.Name = "btn_delete";
            btn_delete.Size = new Size(75, 23);
            btn_delete.TabIndex = 13;
            btn_delete.Text = "Deletar";
            btn_delete.UseVisualStyleBackColor = true;
            // 
            // Tela_principal
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btn_delete);
            Controls.Add(btn_update);
            Controls.Add(btn_adcionar);
            Controls.Add(txt_pendencia);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(txt_data);
            Controls.Add(txt_descricao);
            Controls.Add(label3);
            Controls.Add(txt_titulo);
            Controls.Add(label2);
            Controls.Add(txt_id_tarefa);
            Controls.Add(label1);
            Controls.Add(dgv);
            Name = "Tela_principal";
            Text = "Tela_principal";
            Load += Tela_principal_Load;
            ((System.ComponentModel.ISupportInitialize)dgv).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dgv;
        private Label label1;
        private Label txt_id_tarefa;
        private Label label2;
        private TextBox txt_titulo;
        private TextBox txt_descricao;
        private Label label3;
        private MaskedTextBox txt_data;
        private Label label4;
        private Label label5;
        private ComboBox txt_pendencia;
        private Button btn_adcionar;
        private Button btn_update;
        private Button btn_delete;
    }
}