namespace Tarefas_crud
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            Tela_principal tela1 = new Tela_principal();
            Usuario usuario = new Usuario();
            usuario.Login = txt_login.Text;
            usuario.Senha = txt_senha.Text;

            bool funciona = usuario.Logar();

            if (!txt_login.Text.Equals("") && !txt_senha.Text.Equals(""))
            {
                if (funciona)
                {
                    tela1.Show();
                    this.Hide();
                    MessageBox.Show("login feito com sucesso!!");
                    
                }
                else
                {
                    MessageBox.Show("erro");
                }
            }
        }

        private void btn_chamar_cad_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            tela_cadastro tela = new tela_cadastro();

            tela.Show();
            this.Hide();
        }
    }
}
