﻿using MySql.Data.MySqlClient;
using System;
using System.Windows.Forms; // necessário se usar MessageBox
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tarefas_crud
{
    class Usuario
    {
        private int id;
        private string nome;
        private string login;
        private string email;
        private string senha;

        public int Id
        {
            get { return id; }
            set { id = value; }
        }

        public string Nome
        {
            get { return nome; }
            set { nome = value; }
        }

        public string Email
        {
            get { return email; }
            set { email = value; }
        }

        public string Senha
        {
            get { return senha; }
            set { senha = value; }
        }

        public string Login
        {
            get { return login; }
            set { login = value; }
        }

        public bool CadastarUser()
        {
            try
            {
                using (MySqlConnection conexao = new BancoDb().Conectar())
                {
                    string inserir = "INSERT INTO usuario(nome, email, login, senha) VALUES (@nome, @email, @login, @senha)";

                    MySqlCommand cmd = new MySqlCommand(inserir, conexao);
                    cmd.Parameters.AddWithValue("@nome", Nome);
                    cmd.Parameters.AddWithValue("@login", Login);
                    cmd.Parameters.AddWithValue("@email", Email); 
                    cmd.Parameters.AddWithValue("@senha", Senha);

                    int res = cmd.ExecuteNonQuery(); 

                    return res > 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao cadastrar usuário:\n" + ex.Message);
                return false;
            }
        }

        public bool Logar()
        {
            try
            {
                using (MySqlConnection conexao = new BancoDb().Conectar())
                {
                    string query = "SELECT id FROM usuario WHERE login = @login AND senha = @senha";

                    MySqlCommand cmd = new MySqlCommand(query, conexao);
                    cmd.Parameters.AddWithValue("@login", Login);
                    cmd.Parameters.AddWithValue("@senha", Senha);

                    int result = Convert.ToInt32(cmd.ExecuteScalar());

                    if (result > 0)
                    {
                        Id = Convert.ToInt32(result);
                        return true;
                    }
                    else
                    {
                        MessageBox.Show("Login ou senha incorretos.");
                        return false;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao tentar logar:" + ex.Message);
                return false;
            }
        }
    }
}
